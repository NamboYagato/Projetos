package exercicio1;

public class Main {

    public static void main(String[] args) {
        Pilha pilha = new Pilha();
        System.out.println(pilha.conversor(25));
        pilha.pop();
        System.out.println(pilha.isEmpty());
    }
    
}
